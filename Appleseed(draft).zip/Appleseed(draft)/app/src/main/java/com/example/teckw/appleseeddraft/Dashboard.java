package com.example.teckw.appleseeddraft;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Dashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
    }

    public void goToMcdonalds(View v){
        Intent mcdonaldsPage = new Intent(this, McDonalds.class);
        startActivity(mcdonaldsPage);
    }

    public void goToKFC(View v){
        Intent kfcPage = new Intent(this, KFC.class);
        startActivity(kfcPage);
    }

    public void goToLJS(View v){
        Intent ljsPage = new Intent(this, LongJohnSilvers.class);
        startActivity(ljsPage);
    }

    public void goToBK(View v){
        Intent bkPage = new Intent(this, BurgerKing.class);
        startActivity(bkPage);
    }

    public void goToMenu(View v){
        Intent menuPage = new Intent(this, Menu.class);
        startActivity(menuPage);
    }

    public void goToCart(View v){
        Intent cartPage = new Intent(this, ShoppingCart.class);
        startActivity(cartPage);
    }
}
