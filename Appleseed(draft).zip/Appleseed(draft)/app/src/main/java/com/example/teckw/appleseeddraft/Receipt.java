package com.example.teckw.appleseeddraft;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Receipt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);
    }

    public void goBack(View v){
        Intent homePage = new Intent(this, Dashboard.class);
        startActivity(homePage);
    }
}
