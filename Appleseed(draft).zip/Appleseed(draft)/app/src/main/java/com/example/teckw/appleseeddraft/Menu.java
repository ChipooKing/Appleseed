package com.example.teckw.appleseeddraft;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void goBack(View v){
        Intent homePage = new Intent(this, Dashboard.class);
        startActivity(homePage);
    }

    public void goToParticulars(View v){
        //TODO
    }

    public void goToCart(View v){
        Intent cartPage = new Intent(this, ShoppingCart.class);
        startActivity(cartPage);
    }

    public void goToReceipt(View v){
        //TODO
    }

    public void goLogout(View v){
        finish();
        moveTaskToBack(true);
    }
}
