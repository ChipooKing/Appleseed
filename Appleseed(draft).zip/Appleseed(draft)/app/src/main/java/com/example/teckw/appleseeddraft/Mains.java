package com.example.teckw.appleseeddraft;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Mains extends AppCompatActivity {
    public static String chain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mains);
    }

    public void goBack(View v) {
        if (this.chain == "mcdonalds") {
            Intent mcdonaldsPage = new Intent(this, McDonalds.class);
            startActivity(mcdonaldsPage);
        } else if (this.chain == "kfc") {
            Intent kfcPage = new Intent(this, KFC.class);
            startActivity(kfcPage);
        } else if (this.chain == "ljs") {
            Intent ljsPage = new Intent(this, LongJohnSilvers.class);
            startActivity(ljsPage);
        } else {
            Intent bkPage = new Intent(this, BurgerKing.class);
            startActivity(bkPage);
        }
    }

    public void goToCart(View v){
        Intent cartPage = new Intent(this, ShoppingCart.class);
        startActivity(cartPage);
    }

}
