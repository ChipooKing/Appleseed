package com.example.teckw.appleseeddraft;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class Sides extends AppCompatActivity {
    public static String chain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sides);
    }

    public void goBack(View v){
        if(chain == "mcdonalds"){
            Intent mcdonaldsPage = new Intent(this, McDonalds.class);
            startActivity(mcdonaldsPage);
        }
        else if(chain == "kfc"){
            Intent kfcPage = new Intent(this, KFC.class);
            startActivity(kfcPage);
        }
        else if(chain == "ljs"){
            Intent ljsPage = new Intent(this, LongJohnSilvers.class);
            startActivity(ljsPage);
        }
        else{
            Intent bkPage = new Intent(this, BurgerKing.class);
            startActivity(bkPage);
        }
    }

    public void goToCart(View v){
        Intent cartPage = new Intent(this, ShoppingCart.class);
        startActivity(cartPage);
    }
}
