package com.example.teckw.appleseeddraft;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Payment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
    }

    public void goBack(View v){
        Intent cartPage = new Intent(this, ShoppingCart.class);
        startActivity(cartPage);
    }

    public void finishOrder(View v){
        //if(paymentMode == paypal){
        //Implement paypal API here
        //}
        //else
        Intent receiptPage = new Intent(this, Receipt.class);
        startActivity(receiptPage);
    }
}
