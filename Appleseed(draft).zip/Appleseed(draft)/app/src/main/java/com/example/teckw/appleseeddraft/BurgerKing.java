package com.example.teckw.appleseeddraft;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class BurgerKing extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_burgerking);
    }

    public void goBack(View v){
        Intent homePage = new Intent(this, Dashboard.class);
        startActivity(homePage);
    }

    public void goToCart(View v){
        Intent cartPage = new Intent(this, ShoppingCart.class);
        startActivity(cartPage);
    }

    public void goToMains(View v){
        Mains.chain = "bk";
        Intent mainsPage = new Intent(this, Mains.class);
        startActivity(mainsPage);
    }

    public void goToSides(View v){
        Sides.chain = "bk";
        Intent sidesPage = new Intent(this, Sides.class);
        startActivity(sidesPage);
    }

    public void goToBeverages(View v){
        Beverages.chain = "bk";
        Intent bevPage = new Intent(this, Beverages.class);
        startActivity(bevPage);
    }

    public void goToDesserts(View v){
        Desserts.chain = "bk";
        Intent dessertsPage = new Intent(this, Desserts.class);
        startActivity(dessertsPage);
    }

    public void getMains(){
        //TODO
    }

    public void getSides(){
        //TODO
    }

    public void getBeverages(){
        //TODO
    }

    public void getDesserts(){
        //TODO
    }
}
